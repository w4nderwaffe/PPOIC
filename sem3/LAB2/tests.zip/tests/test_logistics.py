from postal_oop.logistics.PostOffice import PostOffice
from postal_oop.logistics.SortingCenter import SortingCenter
from postal_oop.logistics.Route import Route
from postal_oop.logistics.TransportUnit import TransportUnit
from postal_oop.logistics.Truck import Truck
from postal_oop.logistics.Van import Van
from postal_oop.logistics.TrainCar import TrainCar
from postal_oop.logistics.AirFreight import AirFreight
from postal_oop.logistics.Courier import Courier
from postal_oop.logistics.CourierRoutePlan import CourierRoutePlan
from postal_oop.logistics.Locker import Locker

from postal_oop.core.PostalAddress import PostalAddress
from postal_oop.items.Letter import Letter
from postal_oop.core.Tariff import Tariff
from postal_oop.exceptions.DeliveryAttemptFailedError import DeliveryAttemptFailedError

def test_post_office_and_center_and_route():
    off = PostOffice(id="OFF1", address=PostalAddress("S","1","01103","Vilnius","LT"))
    lt = Letter(tracking_id="T", sender=off.address, recipient=PostalAddress("R","1","44311","Kaunas","LT"), weight_kg=0.2, size_cm=(20,10,1), stamps_value=2.0, tariff=Tariff(code="TN","Nat",3.0,2.5,0.5,"national"))
    assert off.accept_item(lt) >= 0
    sc = SortingCenter(id="HUB1", name="HUB")
    sc.enqueue(lt)
    assert sc.has_item(lt.tracking_id)
    tid = sc.dequeue()
    assert tid == lt.tracking_id
    route = Route(id="R", nodes=["A","B","C"], zone="national")
    assert route.next_after("A") == "B"
    assert route.total_hops() == 2

def test_transport_units_and_courier_and_locker():
    t = Truck(id="T1", kind="truck", max_load_kg=1000.0, axle_count=3, refrigerated=True)
    assert t.fuel_needed(100) > 0
    v = Van(id="V1", kind="van", max_load_kg=500.0)
    assert v.city_efficiency(10) < 1.0
    tr = TrainCar(id="C1", kind="train", max_load_kg=60_000.0)
    assert tr.axle_load_ok()
    af = AirFreight(id="A1", kind="air", max_load_kg=10_000.0, flight_no="AB123")
    assert "FLT" in af.iata_label()

    cur = Courier(full_name="A B", id="C1")
    plan = CourierRoutePlan(courier_id=cur.id)
    plan.add_stop(PostalAddress("S","1","01103","Vilnius","LT"))
    cur.assign_route([plan.stops[0]])
    assert cur.next_stop() is not None
    cur.load(5.0); cur.unload(2.0)
    try:
        cur.attempt_delivery(PostalAddress("S","1","01103","Vilnius","LT"), recipient_present=False)
        assert False
    except DeliveryAttemptFailedError:
        pass

    locker = Locker(id="L1", location=PostalAddress("S","1","01103","Vilnius","LT"), max_weight_per_cell_kg=10.0)
    locker.add_cell("C1")
    locker.put("C1", "TRK", 5.0)
    tid = locker.pickup("C1")
    assert tid == "TRK"
