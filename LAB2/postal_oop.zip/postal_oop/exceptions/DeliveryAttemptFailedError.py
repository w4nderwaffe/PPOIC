class DeliveryAttemptFailedError(Exception):
    """Неудачная попытка доставки (адресат отсутствует/отказ от получения)."""
    pass
