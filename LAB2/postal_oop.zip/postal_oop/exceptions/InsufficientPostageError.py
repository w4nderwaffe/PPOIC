class InsufficientPostageError(Exception):
    """Недостаточно марок/оплаты для выбранного тарифа/веса/зоны."""
    pass
