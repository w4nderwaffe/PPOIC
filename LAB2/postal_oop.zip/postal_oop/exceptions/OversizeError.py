class OversizeError(Exception):
    """Превышены допустимые габариты (длина/ширина/высота/сумма сторон)."""
    pass
