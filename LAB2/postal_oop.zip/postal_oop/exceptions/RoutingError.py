class RoutingError(Exception):
    """Ошибка построения маршрута (нет связности/тарифной зоны/узла)."""
    pass
