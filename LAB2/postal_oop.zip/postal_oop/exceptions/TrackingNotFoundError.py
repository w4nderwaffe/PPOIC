class TrackingNotFoundError(Exception):
    """Трекинг-код не найден в системе."""
    pass
