class OverweightError(Exception):
    """Превышен допустимый вес отправления/ячейки/узла логистики."""
    pass
