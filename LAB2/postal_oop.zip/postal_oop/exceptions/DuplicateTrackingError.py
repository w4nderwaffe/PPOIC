class DuplicateTrackingError(Exception):
    """Дубликат трекинг-кода (конфликт уникальности)."""
    pass
