class LockerOccupiedError(Exception):
    """Ячейка постамата занята или недоступна."""
    pass
