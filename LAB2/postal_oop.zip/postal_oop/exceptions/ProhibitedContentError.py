class ProhibitedContentError(Exception):
    """Обнаружено запрещённое вложение/содержимое (Химия, батареи и т.п.)."""
    pass
