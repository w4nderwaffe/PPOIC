from __future__ import annotations
from dataclasses import dataclass
from postal_oop.items.Parcel import Parcel
from postal_oop.core.InsurancePlan import InsurancePlan

@dataclass
class InsuredParcel(Parcel):
    def require_insurance(self) -> None:
        if not self.insurance or self.declared_value <= 0:
            raise ValueError("Для InsuredParcel нужна страховка и объявленная ценность > 0")
        if not self.insurance.can_cover(self.declared_value):
            raise ValueError("Объявленная ценность превышает покрытие полиса")

    def total_price(self) -> float:
        self.require_insurance()
        return super().total_price()

    def claim_value(self) -> float:
        self.require_insurance()
        # учебно: возвращаем минимальное из заявленной и максимального покрытия
        return min(self.declared_value, self.insurance.max_cover_value)
