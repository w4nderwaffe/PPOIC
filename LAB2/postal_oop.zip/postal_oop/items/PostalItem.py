from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple, List
from postal_oop.core.PostalAddress import PostalAddress
from postal_oop.core.Tariff import Tariff
from postal_oop.core.InsurancePlan import InsurancePlan
from postal_oop.core.Postmark import Postmark
from postal_oop.exceptions.OversizeError import OversizeError
from postal_oop.exceptions.OverweightError import OverweightError
from postal_oop.exceptions.InsufficientPostageError import InsufficientPostageError

@dataclass
class PostalItem:
    tracking_id: str
    sender: PostalAddress
    recipient: PostalAddress
    weight_kg: float
    size_cm: Tuple[float, float, float]      # (L, W, H)
    stamps_value: float = 0.0                # наклеенные марки (суммарно)
    tariff: Optional[Tariff] = None
    insurance: Optional[InsurancePlan] = None
    postmarks: List[Postmark] = field(default_factory=list)
    declared_value: float = 0.0

    def dims(self) -> Tuple[float, float, float]:
        return self.size_cm

    def girth_plus_length(self) -> float:
        L, W, H = self.size_cm
        return L + 2 * (W + H)

    def ensure_weight(self, max_kg: float) -> None:
        if self.weight_kg > max_kg:
            raise OverweightError(f"Вес {self.weight_kg} кг > лимита {max_kg} кг")

    def ensure_size(self, max_lwh_cm: Tuple[float, float, float], max_girth_plus_length: Optional[float] = None) -> None:
        L, W, H = self.size_cm
        ml, mw, mh = max_lwh_cm
        if L > ml or W > mw or H > mh:
            raise OversizeError("Превышены габариты L/W/H")
        if max_girth_plus_length is not None and self.girth_plus_length() > max_girth_plus_length:
            raise OversizeError("Превышена сумма (периметр поперечника + длина)")

    def add_postmark(self, mark: Postmark) -> None:
        self.postmarks.append(mark)

    def total_price(self) -> float:
        if not self.tariff:
            return 0.0
        base = self.tariff.estimate(self.weight_kg)
        ins = self.insurance.premium(self.declared_value) if self.insurance and self.declared_value > 0 else 0.0
        return round(base + ins, 2)

    def verify_postage(self) -> None:
        required = self.total_price()
        if self.stamps_value + 1e-9 < required:
            raise InsufficientPostageError(f"Оплачено {self.stamps_value}, требуется {required}")
