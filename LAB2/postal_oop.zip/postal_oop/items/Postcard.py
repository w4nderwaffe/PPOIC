from __future__ import annotations
from dataclasses import dataclass
from postal_oop.items.PostalItem import PostalItem

@dataclass
class Postcard(PostalItem):
    def service_limits(self) -> dict:
        return {
            "max_weight_kg": 0.05,
            "max_lwh_cm": (15.0, 10.0, 0.5),
            "max_girth_plus_length": 50.0,
        }
