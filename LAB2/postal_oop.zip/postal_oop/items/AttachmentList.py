from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Tuple

@dataclass
class AttachmentList:
    items: List[Tuple[str, float]] = field(default_factory=list)  # (описание, вес кг)

    def add(self, description: str, weight_kg: float) -> None:
        self.items.append((description, max(0.0, weight_kg)))

    def total_weight(self) -> float:
        return round(sum(w for _, w in self.items), 3)

    def keywords(self) -> List[str]:
        kws: List[str] = []
        for desc, _ in self.items:
            kws.extend(desc.lower().split())
        return list(dict.fromkeys(kws))  # уникальные, порядок сохранён
