from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

@dataclass
class CustomsDeclaration:
    contents: str
    declared_value: float
    origin_country: str
    hs_code: Optional[str] = None
    is_document: bool = False

    def requires_declaration(self, international: bool) -> bool:
        if self.is_document:
            return False
        return international and self.declared_value > 0

    def estimate_duties(self, rate_percent: float) -> float:
        return round(self.declared_value * max(0.0, rate_percent) / 100.0, 2)
