from __future__ import annotations
from dataclasses import dataclass
from postal_oop.logistics.TransportUnit import TransportUnit

@dataclass
class AirFreight(TransportUnit):
    flight_no: str = ""
    icao: str = ""  # код аэропорта отправления/прибытия можно хранить отдельно

    def iata_label(self) -> str:
        return f"FLT {self.flight_no}".strip()
