from __future__ import annotations
from dataclasses import dataclass
from postal_oop.logistics.TransportUnit import TransportUnit

@dataclass
class TrainCar(TransportUnit):
    car_number: str = ""
    gauge_mm: int = 1520  # РЖД стандарт

    def axle_load_ok(self) -> bool:
        # учебная проверка: просто ограничение по массе
        return self.max_load_kg >= 50_000
