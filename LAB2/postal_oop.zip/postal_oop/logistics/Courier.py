from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from postal_oop.core.Person import Person
from postal_oop.core.PostalAddress import PostalAddress
from postal_oop.exceptions.DeliveryAttemptFailedError import DeliveryAttemptFailedError

@dataclass
class Courier(Person):
    id: str = ""
    max_carry_kg: float = 25.0
    current_load_kg: float = 0.0
    route: List[PostalAddress] = field(default_factory=list)
    current_stop_idx: int = 0

    def assign_route(self, stops: List[PostalAddress]) -> None:
        self.route = list(stops)
        self.current_stop_idx = 0

    def next_stop(self) -> Optional[PostalAddress]:
        if self.current_stop_idx >= len(self.route):
            return None
        s = self.route[self.current_stop_idx]
        self.current_stop_idx += 1
        return s

    def load(self, weight_kg: float) -> None:
        if self.current_load_kg + weight_kg > self.max_carry_kg + 1e-9:
            raise ValueError("Превышена переносимая масса курьера")
        self.current_load_kg += weight_kg

    def unload(self, weight_kg: float) -> None:
        self.current_load_kg = max(0.0, self.current_load_kg - weight_kg)

    def attempt_delivery(self, address: PostalAddress, recipient_present: bool) -> None:
        if not recipient_present:
            raise DeliveryAttemptFailedError(f"Адресат отсутствует: {address.formatted()}")
