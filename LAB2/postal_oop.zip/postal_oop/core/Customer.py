from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Dict
from postal_oop.core.Person import Person

@dataclass
class Customer(Person):
    loyalty_points: int = 0
    preferred_office_id: Optional[str] = None
    preferences: Dict[str, str] = field(default_factory=dict)

    def add_points(self, amount: int) -> None:
        if amount > 0:
            self.loyalty_points += amount

    def set_preference(self, key: str, value: str) -> None:
        self.preferences[key] = value

    def prefers_office(self, office_id: str) -> bool:
        return self.preferred_office_id == office_id
